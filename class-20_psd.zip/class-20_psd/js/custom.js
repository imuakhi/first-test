$(window).scroll(function(){
   var scrolling= $(window).scrollTop();

    // to show scroll btn
    if(scrolling > 300){
        $(".scroll_btn").fadeIn();
    }
    else{
        $(".scroll_btn").fadeOut();
    }

    // to fixted menu
    if(scrolling > 50){
        $("#manu_full").addClass('menu_fixed');
    }
    else{
        $("#manu_full").removeClass('menu_fixed');
    }


});


// to click scroll btn
$('.scroll_btn').click(function(){
    $('body,html').animate({
        scrollTop : "0px"
    },1500);
});

// form fillup
var name = document.getElementById('userName');
var namErr = document.getElementById('namErr');

var email = document.getElementById('email');
var emailErr = document.getElementById('emailErr');

var password = document.getElementById('password');
var passErr = document.getElementById('passErr');

var rePass = document.getElementById('rePass');
var rePassErr = document.getElementById('rePassErr');

function subm()
{
    // name
    if(userName.value == ''){
    userName.style.border= "1px solid #b22222";
    userName.focus();
    nameErr.innerHTML ="what is your name?";
    return false;
    }

    // email
    if(email.value == ''){
        email.style.border= "1px solid #b22222";
        email.focus();
        emailErr.innerHTML ="what is your email?";
        return false;
    }

    // password
    if(password.value == ''){
        password.style.border= "1px solid #b22222";
        password.focus();
        passErr.innerHTML ="what is your password?";
        return false;
    }

    // length 6 word
    if(password.value.lenght <=5){
        password.style.border= "1px solid #b22222";
        password.focus();
        passErr.innerHTML ="your password must be 6 word!!";
        return false;
    }

     // confirm password
     if(rePass.value == ''){
        rePass.style.border= "1px solid #b22222";
        rePass.focus();
        rePassErr.innerHTML ="what is your password?";
        return false;
    }
    // same as password
    if(rePass.value!= password.value){
        rePass.style.border= "1px solid #b22222";
        rePass.focus();
        rePassErr.innerHTML ="not same?";
        return false;
    }

}

function errValid()
{
    // name
    if(userName.value != ''){
        userName.style.border="1px solid #ffffff66";
        nameErr.innerHTML ="";
    }

    // email
    if(email.value != ''){
        email.style.border="1px solid #ffffff66";
        emailErr.innerHTML ="";
    }

    // password
    if(password.value != ''){
        password.style.border="1px solid #ffffff66";
        passErr.innerHTML ="";
    }

    // confirm password
    if(rePass.value != ''){
        rePass.style.border="1px solid #ffffff66";
        rePassErr.innerHTML ="";
    }
}

userName.addEventListener('blur',errValid);
email.addEventListener('blur',errValid);
password.addEventListener('blur',errValid);
rePass.addEventListener('blur',errValid);

var trigger = document.getElementById('trigger');
var formfull = document.getElementById('modal');
var closeww = document.getElementById('close'); 

trigger.addEventListener("click", function(){
    formfull.style.display = "flex";
});



closeww.addEventListener("click", function(){
    formfull.style.display = "none";
});

